package ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringStarter {
    private static ConfigurableApplicationContext context;
    public static void startApp (){
        if (context == null) {
            context = SpringApplication.run(SpringStarter.class);
        }
    }
}
