package ai.controllers;


import ai.core.CodeComparison;
import ai.core.CodeOverrider;
import ai.core.ServercallAndCheck;
import ai.model.LocatorDetails;
import ai.model.response.FrameworkDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/api")
public class GenerateCodeController {

    @PostMapping("/generateLLMCode")
    public ResponseEntity<?> generateLLMCode(
            @RequestBody ArrayList<LocatorDetails> locatorDetail) {

        StringBuilder result = new StringBuilder();

        int stepNo = 0;
        result.append("\n [Package Details]");
        result.append("\n POM package path: "+CodeOverrider.frameworkConfig.getPomPath());
        result.append("\n Step Definition package path: "+CodeOverrider.frameworkConfig.getStepDefinitionPath());

        for (LocatorDetails locatorDetails : locatorDetail) {

            String action = locatorDetails.getAction();

            if (locatorDetails.getCustomPrompt() != null) {
                action = locatorDetails.getCustomPrompt();
            }

            result.append(
                    "\nStep: " + (++stepNo) + "\n"
                            + "Label: " + locatorDetails.getElementLabel() + "\n"
                            + "Xpath: " + locatorDetails.getElementXpath() + "\n"
                            + "Action: " + action + "\n"
                            + "Application URL: "
                            + locatorDetails.getApplicationURL() + "\n"
            );

            if (locatorDetails.getElementInputValue() != null
                    && !locatorDetails.getElementInputValue().isEmpty()) {

                result.append(
                        "Input Value: "
                                + locatorDetails.getElementInputValue()
                                + "\n");
            }
        }


        System.out.println("************************");
        System.out.println("*** Waiting for LLM response ***");
        System.out.println("************************");

         FrameworkDetails response = ServercallAndCheck.postQueryToLLM(result.toString());
        CodeComparison.checkLLMAndLocalCode(response);
         if (response == null) {
             return ResponseEntity.status(502).body(Map.of(
                     "status", "error",
                     "message", "Failed to generate code from backend response"
             ));
         }

         System.out.println(response);
        return ResponseEntity.ok(response);
    }

    @PostMapping(value = "/applyCode", consumes = "application/json")
    public ResponseEntity<?> applyCode(
            @RequestBody String rawJson) {

        // rawJson contains the exact JSON string sent
        // from the JavaScript frontend.

        System.out.println("Received raw JSON:");
        System.out.println(rawJson);

        CodeOverrider.overrideCode(rawJson);

        HashMap<String, Object> response = new HashMap<>();

        response.put("status", "ok");
        response.put("message", "JSON received as string");
        response.put("received", rawJson);

        return ResponseEntity.ok(response);
    }
}
