package ai.controllers;


import ai.core.App;
import ai.model.LocatorDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

/**
 * REST controller that returns a collection of {@link LocatorDetails}
 * in JSON format.
 */
@RestController
@RequestMapping("/api/locators")
public class LocatorDetailsController {

    /**
     * GET /api/locators
     *
     * Returns a static list of LocatorDetails objects.
     *
     * @return list of LocatorDetails serialized as JSON
     */
    @GetMapping
    public List<LocatorDetails> getAllLocators() {
        try {

            Object obj =
                    App.clazzCodeGen.getDeclaredConstructor()
                            .newInstance();
            Field field = App.clazzCodeGen.getDeclaredField("steps");
            field.setAccessible(true);
            List<LocatorDetails> details = (List<LocatorDetails>) field.get(null);
            return details;

        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/clear")
    public String clearSteps() {

        try {

            Object obj =
                    App.clazzCodeGen.getDeclaredConstructor()
                            .newInstance();
            Field field = App.clazzCodeGen.getDeclaredField("steps");
            field.setAccessible(true);
            field.set(null, new ArrayList<>() );
        }catch (Exception e){
            e.printStackTrace();
        }

        return "All locator steps have been cleared.";
    }

    @PostMapping("/locatorInput")
    public String locatorDetails(
            ArrayList<LocatorDetails> locatorDetails) {

        return "All locator steps have been cleared.";
    }
}