package ai.controllers;

import ai.core.App;
import ai.core.ServercallAndCheck;
import ai.model.JSModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LoginController {
    public static boolean isLogin = false;

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(
            @RequestParam String userEmail,
            @RequestParam String userName) {

        Map<String, String> response = new HashMap<>();
        response.put("userEmail", userEmail);
        response.put("userName", userName);
        response.put("message", "Login request received");
        System.out.println("Response --> "+response.toString());
        JSModel jsModel =  ServercallAndCheck.getJsScriptDetails(userName,userEmail);
        if(jsModel.lowBalance == true ){
            response.put("message", "low balance");
        }
        Field userNameCodGen = null;
        Field userEmailCodGen = null;
        try {
            userNameCodGen = App.clazzCodeGen.getDeclaredField("userName");
            userNameCodGen.setAccessible(true);
            userNameCodGen.set(null,userName );
            userEmailCodGen = App.clazzCodeGen.getDeclaredField("emailId");
            userEmailCodGen.setAccessible(true);
            userEmailCodGen.set(null,userEmail );

        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        isLogin = true;
        return ResponseEntity.ok(response);
    }
}
