package ai.core;

import ai.SpringStarter;
import ai.model.FrameworkConfig;
import ai.utils.Helper;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;

public class App {
    public static Class<?> clazzCodeGen = null;
    public static void main(String[] args) {
        //SpringStarter.startApp();
        FrameworkConfig frameworkConfig = new FrameworkConfig("cdv","csd","fs","https://demo.automationtesting.in/Register.html");
       // CodeGenerator.codeGen(frameworkConfig);

        startCodeGen(frameworkConfig);
    }
    public static void startCodeGen(FrameworkConfig frameworkConfig){
        SpringStarter.startApp();
        InputStream is = App.class.getClassLoader()
                .getResourceAsStream("encrypted/codeGen.txt");

        try {
            String source = new String(is.readAllBytes());
            CompilationUnit cu =
                    StaticJavaParser.parse(source);


            Path tempDir = Files.createTempDirectory("runtime");
            Path packageDir = tempDir.resolve("ai/core");
            Files.createDirectories(packageDir);

            Path javaFile = packageDir.resolve("CodeGenerator.java");
            Files.writeString(javaFile, source);

            JavaCompiler compiler =
                    ToolProvider.getSystemJavaCompiler();

            int result = compiler.run(
                    null,
                    null,
                    null,
                    javaFile.toString()
            );

            if (result != 0) {
                throw new RuntimeException("Compilation failed");
            }
            Files.deleteIfExists(javaFile);
            URLClassLoader loader =
                    URLClassLoader.newInstance(
                            new URL[]{
                                    tempDir.toUri().toURL()
                            });

             clazzCodeGen =
                    loader.loadClass("ai.core.CodeGenerator");
            Object obj =
                    clazzCodeGen.getDeclaredConstructor()
                            .newInstance();


            Method method = clazzCodeGen.getMethod("codeGen", FrameworkConfig.class);
            method.invoke(obj,frameworkConfig);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
           // throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }

      //  CodeGenerator.codeGen(frameworkConfig);
    }
}
