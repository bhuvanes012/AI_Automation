package ai.core;

import ai.model.CodeCompareModel;
import ai.model.response.CodeComponent;
import ai.model.response.FrameworkDetails;
import ai.model.response.MethodData;
import ai.utils.Helper;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.SimpleName;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ai.core.CodeOverrider.frameworkConfig;

public class CodeComparison {

    public static void checkLLMAndLocalCode(FrameworkDetails frameworkDetails) {
        String pomPath = frameworkConfig.getPomPath();
        String stepDefinitionPath = frameworkConfig.getStepDefinitionPath();
        String featurePath = frameworkConfig.getFeaturePath();


        ArrayList<CodeComponent> pomComponent =  constructClass( frameworkDetails.getFramework().getComponents().getPom(), pomPath,true);
        frameworkDetails.getFramework().getComponents().setPom(pomComponent);

        ArrayList<CodeComponent> stepDefinitionComponent =  constructClass( frameworkDetails.getFramework().getComponents().getStepDefinition(), stepDefinitionPath,true);
        frameworkDetails.getFramework().getComponents().setStepDefinition(stepDefinitionComponent);


    }

    private static ArrayList<CodeComponent> constructClass( ArrayList<CodeComponent> components, String packagePath, boolean isPom) {
        try {
            for (int i=0 ;i<components.size();i++) {
                try {
                    Boolean isFilePresent = Helper.isJavaFilePresent(components.get(i).getFile(), packagePath);

                    String pomPath = packagePath + components.get(i).getFile();

                    if (isFilePresent) {
                        components.get(i).setClassExist(true);
                        File filePath = new File(pomPath);
                        CompilationUnit cu = StaticJavaParser.parse(filePath);
                        updateImports(cu, components,i);
                        updateVariables(cu, components,i);
                        updateMethods(cu, components,i);
                    }
                }catch (Exception e){

                }

            }
            return  components;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public  static  void updateImports(CompilationUnit cu, List<CodeComponent>  components,int index){
        try{
            List<String> currentLocalFileImports = cu.getImports().stream().map(ImportDeclaration::toString).collect(Collectors.toList());
            List<String> imports= components.get(index).getImports();
            List<CodeCompareModel> importCompare = new ArrayList<>();
            for(int i=0;i<imports.size();i++){
                String llmImportState = imports.get(i);
                CodeCompareModel importData = new CodeCompareModel();
                importData.setLlmContent(llmImportState);
                boolean isImportPresent = false;
                for (String currentImport : currentLocalFileImports) {
                    if (currentImport.contains(llmImportState)) {
                        isImportPresent = true;
                        importData.setLocalContent(currentImport);
                        break;
                    }
                }
                if (isImportPresent) {
                    importData.setLLMContent(true);
                }
                importCompare.add(importData);

            }
            components.get(index).setImportsComparison(importCompare);


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public  static  void updateVariables(CompilationUnit cu, List<CodeComponent>  components,int index){
        try{
            List<String> localAllVariables = cu.findAll(FieldDeclaration.class).stream().flatMap(fd -> fd.getVariables().stream()).map(VariableDeclarator::getName).map(SimpleName::asString).collect(Collectors.toList());
            List<String> llmVariables = components.get(index).getVariables();
            List<CodeCompareModel> listOfvariableCompare = new ArrayList<>();
            for(int i=0;i<llmVariables.size();i++){
                String llmVariable = llmVariables.get(i);
                CodeCompareModel variableCompare = new CodeCompareModel();
                variableCompare.setLlmContent(llmVariable);
                for (String localVariable : localAllVariables) {
                    if (llmVariable.trim().contains(localVariable.trim())) {

                        Optional<FieldDeclaration> field = cu.findAll(FieldDeclaration.class)
                                .stream()
                                .filter(fd -> fd.getVariables().stream()
                                        .anyMatch(v -> v.getNameAsString().equals(localVariable)))
                                .findFirst();

                        if (field.isPresent()) {
                            variableCompare.setLocalContent(field.get().toString());
                        }

                    }
                }
                listOfvariableCompare.add(variableCompare);
            }
            components.get(index).setVariablesComparison(listOfvariableCompare);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public  static  void updateMethods(CompilationUnit cu, List<CodeComponent>  components,int index) {
        try {
            List<String> LocalMethodNames = cu.findAll(MethodDeclaration.class).stream().map(MethodDeclaration::getNameAsString).collect(Collectors.toList());
            List<String> constructorNames = cu.findAll(ConstructorDeclaration.class).stream().map(ConstructorDeclaration::getNameAsString).collect(Collectors.toList());
            LocalMethodNames = Stream.concat(LocalMethodNames.stream(), constructorNames.stream()).collect(Collectors.toList());
            String className = components.get(index).getFile().replace(".java", "");
            List<CodeCompareModel> listOfMethodsCompare = new ArrayList<>();
            List<MethodData> methodDetails = components.get(index).getMethods() ;
            for(int i=0 ;i<methodDetails.size();i++){
                String llMmethodCode = methodDetails.get(i).getCode();
                CodeCompareModel methodCompare = new CodeCompareModel();
                methodCompare.setLlmContent(llMmethodCode);
               String  existingMethod = findExistingMethod(cu,className,llMmethodCode);
               if(existingMethod !=null){
                   methodCompare.setLocalContent(existingMethod);
                   methodDetails.get(i).setMethodExist(true);
               }
                methodDetails.get(i).setMethodCode(methodCompare);
            }

            components.get(index).setMethods(methodDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static String findExistingMethod(CompilationUnit cu,
                                             String className,
                                             String methodCode) {

        Optional<ClassOrInterfaceDeclaration> clazz =
                cu.getClassByName(className);

        if (clazz.isEmpty()) {
            return null;
        }

        BodyDeclaration<?> body;

        try {
            body = StaticJavaParser.parseBodyDeclaration(methodCode.trim());
        } catch (Exception e) {
            // methodCode contains multiple members or invalid syntax
            return null;
        }

        // ---------------- Methods ----------------
        if (body instanceof MethodDeclaration newMethod) {

            for (MethodDeclaration existingMethod : clazz.get().getMethods()) {

                if (!existingMethod.getNameAsString()
                        .equals(newMethod.getNameAsString())) {
                    continue;
                }

                if (existingMethod.getParameters().size()
                        != newMethod.getParameters().size()) {
                    continue;
                }

                boolean sameParameters = true;

                for (int i = 0; i < existingMethod.getParameters().size(); i++) {

                    String existingType = existingMethod.getParameter(i)
                            .getType().asString();

                    String newType = newMethod.getParameter(i)
                            .getType().asString();

                    if (!existingType.equals(newType)) {
                        sameParameters = false;
                        break;
                    }
                }

                if (sameParameters) {
                    return existingMethod.toString();
                }
            }
        }

        // ---------------- Constructors ----------------
        if (body instanceof ConstructorDeclaration newConstructor) {

            for (ConstructorDeclaration existingConstructor :
                    clazz.get().getConstructors()) {

                if (existingConstructor.getParameters().size()
                        != newConstructor.getParameters().size()) {
                    continue;
                }

                boolean sameParameters = true;

                for (int i = 0; i < existingConstructor.getParameters().size(); i++) {

                    String existingType = existingConstructor.getParameter(i)
                            .getType().asString();

                    String newType = newConstructor.getParameter(i)
                            .getType().asString();

                    if (!existingType.equals(newType)) {
                        sameParameters = false;
                        break;
                    }
                }

                if (sameParameters) {
                    return existingConstructor.toString();
                }
            }
        }

        return null;
    }

}
