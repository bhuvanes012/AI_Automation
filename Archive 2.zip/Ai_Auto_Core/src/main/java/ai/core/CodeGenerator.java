//package ai.core;
//
//import ai.controllers.LoginController;
//import ai.model.FrameworkConfig;
//import ai.model.JSModel;
//import ai.model.LocatorDetails;
//import ai.utils.BackendResponseEncryptor;
//import ai.utils.BackendResponseDecryptor;
//import ai.utils.SeleniumUtils;
//import io.github.bonigarcia.wdm.WebDriverManager;
//import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import java.awt.*;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//import java.net.URI;
//import java.net.URISyntaxException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Properties;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//
//public class CodeGenerator {
//    public static WebElement lastClickElement;
//
//
//    public static List<LocatorDetails> steps = new ArrayList<>();
//    public static JSModel jsModel = null;
//    public static WebDriver driver = null;
//    public  static String userName="";
//    public static String emailId ="";
//
//    public static void codeGen(FrameworkConfig frameworkConfig) {
//
//        CodeOverrider.frameworkConfig = frameworkConfig;
//
//        try {
//            WebDriverManager.chromedriver().setup();
//            driver = new ChromeDriver();
//
//        }catch (Exception e){
//            e.printStackTrace();
//            throw new RuntimeException("Could not able to initialize driver : "+e.getMessage());
//        }
//        validateConfig(frameworkConfig);
//        driver.get(CodeOverrider.frameworkConfig.getApplicationUrl());
//        if(jsModel==null){
//            jsModel = ServercallAndCheck.getJsScriptDetails(userName,emailId);
//        }
//        injectScript(driver);
//
//
//        if (jsModel == null
//                || jsModel.getJsElementListener() == null
//                || jsModel.getMouseHighlight() == null
//                || jsModel.getJsListOfXpathGenerator() == null) {
//            throw new IllegalStateException("Failed to load browser scripts from backend");
//        }
//
//        while (true) {
//
//            try {
//
//                Thread.sleep(500);
//
//                // getStoredEvents(DriverFactory.getDriver());
//
//                WebElement element = getLastClickedElement(driver);
//
//                if (element != null) {
//
//                    System.out.println(element.getTagName());
//
//                    if (lastClickElement == null || (!lastClickElement.equals(element))) {
//
//                        System.out.println("New click happened: " + element.getTagName());
//
//                        lastClickElement = element;
//
//                        SeleniumUtils.highlightElement(driver, element);
//
//                        String elementText = "";
//
//                        List<WebElement> childElements =
//                                element.findElements(By.xpath("./*"));
//
//                        if (childElements.size() > 1) {
//                            elementText = childElements.get(0)
//                                    .getAttribute("textContent");
//                        } else {
//                            elementText = element.getAttribute("textContent");
//                        }
//
//                        String splitedLabel =
//                                beforeFirstSpecial(elementText);
//
//                        List<String> elementXpathList =
//                                (List<String>) ((JavascriptExecutor) driver)
//                                        .executeScript(
//                                                getXPathJs(),
//                                                element,
//                                                splitedLabel.trim()
//                                        );
//
//                        System.out.println(
//                                "Xpath ->>>> "
//                                        + Arrays.toString(
//                                        elementXpathList.toArray()
//                                )
//                        );
//
//                        for (String xpath : elementXpathList) {
//                            System.out.println(xpath);
//                        }
//
//                        LocatorDetails elementDetail =
//                                new LocatorDetails();
//
//                        elementDetail.setLisOfXpath(elementXpathList);
//                        elementDetail.setElementHTML(
//                                element.getAttribute("outerHTML")
//                        );
//                        elementDetail.setElementXpath("");
//                        elementDetail.setElementLabel(
//                                elementText.trim()
//                        );
//                        elementDetail.setApplicationURL(
//                                driver.getCurrentUrl()
//                        );
//
//                        if (steps.size() == 0) {
//
//                            LocatorDetails applicationLoad =
//                                    new LocatorDetails();
//
//                            applicationLoad.setElementHTML(
//                                    element.getAttribute("outerHTML")
//                            );
//
//                            applicationLoad.setElementXpath("");
//
//                            applicationLoad.setElementLabel(
//                                    "Load the Application URL:\n"
//                                            + driver.getCurrentUrl()
//                            );
//
//                            applicationLoad.setApplicationURL(
//                                    driver.getCurrentUrl()
//                            );
//
//                            applicationLoad.setAction(
//                                    "Load the application URL: "
//                                            + driver.getCurrentUrl()
//                            );
//
//                            steps.add(applicationLoad);
//                        }
//
//                        steps.add(elementDetail);
//
//
//                    } else {
//
//                        System.out.println("No changes");
//
//                        if (element.getTagName().toLowerCase().trim()
//                                .equalsIgnoreCase("input")) {
//
//                            String value =
//                                    element.getAttribute("value");
//
//                            steps.get(steps.size() - 1).setElementInputValue(value);
//                        }
//                    }
//                }
//
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//                System.err.println("Code generation loop interrupted: " + e.getMessage());
//                break;
//            } catch (Exception e) {
//                System.err.println("Code generation error: " + e.getMessage());
//            }
//        }
//    }
//
//    private static void validateConfig(FrameworkConfig frameworkConfig) {
//        Path systemConfigPath = Paths.get("src/main/resources/systemConfig.properties");
//
//        try {
//            if (Files.exists(systemConfigPath)) {
//                Properties properties = new Properties();
//                try (InputStream inputStream = Files.newInputStream(systemConfigPath)) {
//                    properties.load(inputStream);
//                }
//
//                userName = BackendResponseDecryptor.decrypt(properties.getProperty("userName"));
//                emailId = BackendResponseDecryptor.decrypt(properties.getProperty("emailId"));
//            } else {
//                if (systemConfigPath.getParent() != null) {
//                    Files.createDirectories(systemConfigPath.getParent());
//                }
//               // Files.createFile(systemConfigPath);
//                openBrowser("http://localhost:8095/indexOtp.html");
//                while (!LoginController.isLogin){
//                    Thread.sleep(2000);
//                }
//                saveEncryptedSystemConfig(systemConfigPath);
//
//
//            }
//
//        } catch (IOException e) {
//            throw new IllegalStateException("Unable to create systemConfig.properties", e);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    private static void saveEncryptedSystemConfig(Path systemConfigPath) throws IOException {
//        Properties properties = new Properties();
//
//        if (Files.exists(systemConfigPath)) {
//            try (InputStream inputStream = Files.newInputStream(systemConfigPath)) {
//                properties.load(inputStream);
//            }
//        }
//
//        properties.setProperty("userName", BackendResponseEncryptor.encrypt(userName));
//        properties.setProperty("emailId", BackendResponseEncryptor.encrypt(emailId));
//
//        try (OutputStream outputStream = Files.newOutputStream(
//                systemConfigPath,
//                java.nio.file.StandardOpenOption.CREATE,
//                java.nio.file.StandardOpenOption.TRUNCATE_EXISTING,
//                java.nio.file.StandardOpenOption.WRITE)) {
//            properties.store(outputStream, null);
//        }
//    }
//
//    static void openBrowser(String url) throws IOException {
//        String os = System.getProperty("os.name").toLowerCase();
//
//        if (os.contains("mac")) {
//            new ProcessBuilder("open", url).start();
//        } else if (os.contains("win")) {
//            new ProcessBuilder("cmd", "/c", "start", "", url).start();
//        } else {
//            new ProcessBuilder("xdg-open", url).start();
//        }
//    }
//
//    public static void injectScript(WebDriver driver) {
//
//        String jsCode = jsModel.getJsElementListener();
//
//
//        String mouseHighlight = jsModel.getMouseHighlight();
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript(jsCode);
//        js.executeScript(mouseHighlight);
//    }
//
//
//    public static String getXPathJs() {
//
//        String script = jsModel.getJsListOfXpathGenerator();
//        return script;
//    }
//
//    @SuppressWarnings("unchecked")
//    private static WebElement getLastClickedElement(WebDriver driver) {
//
//        try {
//            Boolean isEventStoreAvailable = (Boolean) ((JavascriptExecutor) driver)
//                    .executeScript(
//                            "return typeof window._eventStore !== 'undefined' && window._eventStore !== null;"
//                    );
//
//            if (isEventStoreAvailable) {
//
//                Object raw = ((JavascriptExecutor) driver)
//                        .executeScript("return window._eventStore || [null, null];");
//
//                List<WebElement> elements = (List<WebElement>) raw;
//
//                if (elements.get(1) != null
//                        && elements.get(1).getTagName().equalsIgnoreCase("iframe")) {
//
//                    driver.switchTo().frame(elements.get(1));
//
//
//                    injectScript(driver);
//
//                    //tempIframeElement = elements.get(0);
//                    lastClickElement = null;
//
//                    System.out.println("Switched to iframe");
//
//                    return lastClickElement;
//                }
//
////                if (temp != null) {
////
////                    Object rawTemp = ((JavascriptExecutor) driver)
////                            .executeScript("return window._eventStore || [null, null];");
////
////                    List<WebElement> tempElements = (List<WebElement>) rawTemp;
////
////                    if (tempElements.get(0) != null) {
////                        System.out.println(tempElements.get(0).getTagName());
////                    }
////                }
//
//                return elements.get(0);
//
//            } else {
//                injectScript(driver);
//            }
//
//        } catch (Exception e) {
//            System.err.println("Unable to read last clicked element: " + e.getMessage());
//            return lastClickElement;
//        }
//
//        return lastClickElement;
//    }
//
//    public static String beforeFirstSpecial(String input) {
//
//        if (input == null || input.isEmpty()) {
//            return input;
//        }
//
//        // Match alphanumeric characters from the start of the string
//        java.util.regex.Matcher matcher = java.util.regex.Pattern
//                .compile("^[A-Za-z0-9]*")
//                .matcher(input);
//
//        if (matcher.find()) {
//            return matcher.group();
//        }
//
//        // Should never happen because the regex always matches at least ""
//        return "";
//    }
//}
