package ai.core;

import java.net.NetworkInterface;
import java.util.Collections;

public class MacAddress {
    public static void main(String[] args) {
        System.out.println(getDeviceMacAddress());
    }

    public static String getDeviceMacAddress() {

        try {

            for (NetworkInterface ni :
                    Collections.list(NetworkInterface.getNetworkInterfaces())) {

                if (!ni.isUp()
                        || ni.isLoopback()
                        || ni.isVirtual()) {
                    continue;
                }

                byte[] mac = ni.getHardwareAddress();

                if (mac == null || mac.length == 0) {
                    continue;
                }

                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < mac.length; i++) {
                    sb.append(String.format(
                            "%02X%s",
                            mac[i],
                            (i < mac.length - 1) ? ":" : ""));
                }

                return sb.toString();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
