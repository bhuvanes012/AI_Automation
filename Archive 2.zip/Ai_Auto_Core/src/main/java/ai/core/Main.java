package ai.core;

import ai.model.CodeCompareModel;
import ai.model.FrameworkConfig;
import ai.model.response.FrameworkDetails;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ObjectMapper mapper = new ObjectMapper();

        try {
            FrameworkConfig frameworkConfig = new FrameworkConfig("/Users/bhuvanes/AI_Tool/QaAutowire/src/test/java/ai/pom/","/Users/bhuvanes/AI_Tool/QaAutowire/src/test/java/stepdefinitions/","/Users/bhuvanes/AI_Tool/QaAutowire/src/test/resources/features/","https://demo.automationtesting.in/Register.html");
            CodeOverrider.frameworkConfig = frameworkConfig;
            FrameworkDetails config = mapper.readValue(readResourceFile("SampleResponse.txt"), FrameworkDetails.class);
            CodeCompareModel variable = new CodeCompareModel();
            List<CodeCompareModel> variableList = new ArrayList<>();
            variableList.add(variable);
            config.getFramework().getComponents().getPom().get(0).setVariablesComparison(variableList);
            config.getFramework().getComponents().getStepDefinition().get(0).setVariablesComparison(variableList);
            config.getFramework().getComponents().getPom().get(0).setImportsComparison(variableList);
            config.getFramework().getComponents().getStepDefinition().get(0).setImportsComparison(variableList);
            // Print as formatted JSON

            CodeComparison.checkLLMAndLocalCode(config);

            System.out.println(config.toString());
        } catch (IOException e) {
           e.printStackTrace();
        }
    }

    public static String readResourceFile(String fileName) throws IOException {
        try (InputStream inputStream =
                     Main.class.getClassLoader().getResourceAsStream(fileName)) {

            if (inputStream == null) {
                throw new IOException("File not found: " + fileName);
            }

            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

}
