package ai.core;

import ai.model.JSModel;
import ai.model.response.BackendJsScriptResponse;
import ai.model.response.BackendLlmResponse;
import ai.model.response.FrameworkDetails;
import ai.utils.BackendResponseDecryptor;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class ServercallAndCheck {
    public static final String baseUrl = System.getProperty(
            "ai.backend.baseUrl",
            System.getenv().getOrDefault("AI_BACKEND_BASE_URL", "http://localhost:8095")
    );

    public static void main(String[] args) throws Exception {
      postQueryToLLM("hrllo" );
//getJsScriptDetails();
    }

    public static JSModel getJsScriptDetails(String userName,String emailId) {
        JSModel jsModel = null;
        try {
            HttpClient client = HttpClient.newHttpClient();
            String macAddress = MacAddress.getDeviceMacAddress();


            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/api/jsScript?macAddress=" +
                            URLEncoder.encode(macAddress, StandardCharsets.UTF_8) +
                            "&phoneNumber=" + URLEncoder.encode(emailId, StandardCharsets.UTF_8) +
                            "&userName=" + URLEncoder.encode(userName, StandardCharsets.UTF_8)))
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println(response.body());
            ObjectMapper mapper = new ObjectMapper();

            BackendJsScriptResponse backendResponse =
                    mapper.readValue(response.body(), BackendJsScriptResponse.class);

            if (backendResponse.isLowBalance()) {
                throw new IllegalStateException(
                        backendResponse.getMessage() != null
                                ? backendResponse.getMessage()
                                : "Low balance returned from backend"
                );
            }

            jsModel = new JSModel();
            jsModel.setJsElementListener(backendResponse.getJsElementListener());
            jsModel.setMouseHighlight(backendResponse.getMouseHighlight());
            jsModel.setJsListOfXpathGenerator(backendResponse.getJsListOfXpathGenerator());
            jsModel.setStatus(backendResponse.getStatus());
            jsModel.setMessage(backendResponse.getMessage());
            jsModel.setPhoneNumber(backendResponse.getPhoneNumber());
            jsModel.setUserName(backendResponse.getUserName());
            jsModel.setMacAddress(backendResponse.getMacAddress());
            jsModel.setLowBalance(backendResponse.isLowBalance());
            jsModel.setNewUser(backendResponse.isNewUser());
            jsModel.setBalanceAmount(backendResponse.getBalanceAmount() == null ? "" : backendResponse.getBalanceAmount().toPlainString());
            System.out.println(jsModel);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsModel;
    }

    public static FrameworkDetails postQueryToLLM(String query) {
        try {
            String macAddress = MacAddress.getDeviceMacAddress();
            Field field = App.clazzCodeGen.getDeclaredField("emailId");
            field.setAccessible(true);
            String phoneNumber = field.get(null).toString();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/api/llm?phoneNumber=" +
                            URLEncoder.encode(phoneNumber, StandardCharsets.UTF_8) +
                            "&query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)))
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();

            HttpResponse<String> response = HttpClient.newHttpClient()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println(response.body());
            ObjectMapper mapper = new ObjectMapper();

            BackendLlmResponse backendResponse =
                    mapper.readValue(response.body(), BackendLlmResponse.class);

            if (backendResponse.isLowBalance()) {
                throw new IllegalStateException(
                        backendResponse.getMessage() != null
                                ? backendResponse.getMessage()
                                : "Low balance returned from backend"
                );
            }

            String decryptedResponse = BackendResponseDecryptor.decrypt(backendResponse.getEncryptedResponse());
            FrameworkDetails frameworkDetails = mapper.readValue(decryptedResponse, FrameworkDetails.class);
            CodeComparison.checkLLMAndLocalCode(frameworkDetails);
            return  frameworkDetails;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String resolvePhoneNumber(String macAddress) {
        String configured = System.getProperty(
                "ai.backend.phoneNumber",
                System.getenv().getOrDefault("AI_BACKEND_PHONE_NUMBER", "")
        );
        if (configured != null && !configured.isBlank()) {
            return configured;
        }

        String seed = macAddress == null ? "unknown-device" : macAddress.replaceAll("[^A-Za-z0-9]", "");
        String digits = String.valueOf(Math.abs(seed.hashCode()));
        return digits.length() > 10 ? digits.substring(0, 10) : digits;
    }

    private static String resolveUserName() {
        String configured = System.getProperty(
                "ai.backend.userName",
                System.getenv().getOrDefault("AI_BACKEND_USER_NAME", "AutoUser")
        );
        return configured == null || configured.isBlank() ? "AutoUser" : configured;
    }
}
