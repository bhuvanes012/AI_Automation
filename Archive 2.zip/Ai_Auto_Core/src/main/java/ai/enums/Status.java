package ai.enums;

public enum Status {
    INPROGRESS, COMPLETED, YETTOSTART,READTOPROCESS, FAILURE;
}
