package ai.model;

public class CodeCompareModel {
    private String llmContent="";
    private String localContent ="";
    private Boolean isLLMContent = true;

    public String getLlmContent() {
        return llmContent;
    }

    public void setLlmContent(String llmContent) {
        this.llmContent = llmContent;
    }

    public String getLocalContent() {
        return localContent;
    }

    public void setLocalContent(String localContent) {
        this.localContent = localContent;
    }

    public Boolean getLLMContent() {
        return isLLMContent;
    }

    public void setLLMContent(Boolean LLMContent) {
        isLLMContent = LLMContent;
    }
}
