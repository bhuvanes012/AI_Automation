package ai.model;

public class FrameworkConfig {

    private String pomPath;
    private String featurePath;
    private String stepDefinitionPath;
    private String applicationUrl = "";


       public FrameworkConfig(String pomPath,
                String stepDefinitionPath,
                String featurePath, String applicationUrl ) {

            this.pomPath = validate(pomPath, "Pom file path", true);
            this.stepDefinitionPath = validate(stepDefinitionPath, "Step Definition path", true);
            this.featurePath = validate(featurePath, "Feature file path", true);
            this.applicationUrl = validateNotEmpty(applicationUrl);
        }

    private String validateNotEmpty(String applicationUrl) {
           if(applicationUrl=="" | applicationUrl == null){
               throw new IllegalArgumentException(  "Application url cannot be null or empty.");
           }
           return applicationUrl;
    }

    private String validate(String value, String fieldName, boolean isFolder) {

            if (value == null || value.trim().isEmpty()) {
                throw new IllegalArgumentException(fieldName + " cannot be null or empty.");
            }

            value = value.trim();

            if (isFolder && !value.endsWith("/") && !value.endsWith("\\")) {
                value += "/";
            }

            return value;
        }


        public String getPomPath() {
        return pomPath;
    }

    public String getFeaturePath() {
        return featurePath;
    }

    public void setPomPath(String pomPath) {
        this.pomPath = pomPath;
    }

    public void setFeaturePath(String featurePath) {
        this.featurePath = featurePath;
    }

    public void setStepDefinitionPath(String stepDefinitionPath) {
        this.stepDefinitionPath = stepDefinitionPath;
    }

    public String getApplicationUrl() {
        return applicationUrl;
    }

    public void setApplicationUrl(String applicationUrl) {
        this.applicationUrl = applicationUrl;
    }

    public String getStepDefinitionPath() {
        return stepDefinitionPath;
    }


}