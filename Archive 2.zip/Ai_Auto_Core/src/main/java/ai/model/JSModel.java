package ai.model;

public class JSModel {

    public  String jsElementListener="";
    public  String mouseHighlight ="";
    public  String jsListOfXpathGenerator ="";
    public String status = "";
    public String message = "";
    public String phoneNumber = "";
    public String userName = "";
    public String macAddress = "";
    public Boolean lowBalance = false;
    public Boolean newUser = false;
    public String balanceAmount = "";

    public String getJsElementListener() {
        return jsElementListener;
    }

    public void setJsElementListener(String jsElementListener) {
        this.jsElementListener = jsElementListener;
    }

    public String getMouseHighlight() {
        return mouseHighlight;
    }

    public void setMouseHighlight(String mouseHighlight) {
        this.mouseHighlight = mouseHighlight;
    }

    public String getJsListOfXpathGenerator() {
        return jsListOfXpathGenerator;
    }

    public void setJsListOfXpathGenerator(String jsListOfXpathGenerator) {
        this.jsListOfXpathGenerator = jsListOfXpathGenerator;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public Boolean getLowBalance() {
        return lowBalance;
    }

    public void setLowBalance(Boolean lowBalance) {
        this.lowBalance = lowBalance;
    }

    public Boolean getNewUser() {
        return newUser;
    }

    public void setNewUser(Boolean newUser) {
        this.newUser = newUser;
    }

    public String getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(String balanceAmount) {
        this.balanceAmount = balanceAmount;
    }
}
