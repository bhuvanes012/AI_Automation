package ai.model.response;

import java.math.BigDecimal;

public class BackendJsScriptResponse {
    private String status;
    private String message;
    private String phoneNumber;
    private String userName;
    private String macAddress;
    private boolean lowBalance;
    private boolean newUser;
    private BigDecimal balanceAmount;
    private String jsElementListener;
    private String mouseHighlight;
    private String jsListOfXpathGenerator;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public boolean isLowBalance() {
        return lowBalance;
    }

    public void setLowBalance(boolean lowBalance) {
        this.lowBalance = lowBalance;
    }

    public boolean isNewUser() {
        return newUser;
    }

    public void setNewUser(boolean newUser) {
        this.newUser = newUser;
    }

    public BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(BigDecimal balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public String getJsElementListener() {
        return jsElementListener;
    }

    public void setJsElementListener(String jsElementListener) {
        this.jsElementListener = jsElementListener;
    }

    public String getMouseHighlight() {
        return mouseHighlight;
    }

    public void setMouseHighlight(String mouseHighlight) {
        this.mouseHighlight = mouseHighlight;
    }

    public String getJsListOfXpathGenerator() {
        return jsListOfXpathGenerator;
    }

    public void setJsListOfXpathGenerator(String jsListOfXpathGenerator) {
        this.jsListOfXpathGenerator = jsListOfXpathGenerator;
    }
}
