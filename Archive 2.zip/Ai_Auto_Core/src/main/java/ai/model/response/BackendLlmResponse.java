package ai.model.response;

import java.math.BigDecimal;

public class BackendLlmResponse {
    private String status;
    private String message;
    private String phoneNumber;
    private BigDecimal balanceAmount;
    private String encryptedResponse;
    private long inputTokens;
    private long outputTokens;
    private long cacheTokens;
    private BigDecimal totalCost;
    private String interactionTime;
    private boolean lowBalance;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(BigDecimal balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public String getEncryptedResponse() {
        return encryptedResponse;
    }

    public void setEncryptedResponse(String encryptedResponse) {
        this.encryptedResponse = encryptedResponse;
    }

    public long getInputTokens() {
        return inputTokens;
    }

    public void setInputTokens(long inputTokens) {
        this.inputTokens = inputTokens;
    }

    public long getOutputTokens() {
        return outputTokens;
    }

    public void setOutputTokens(long outputTokens) {
        this.outputTokens = outputTokens;
    }

    public long getCacheTokens() {
        return cacheTokens;
    }

    public void setCacheTokens(long cacheTokens) {
        this.cacheTokens = cacheTokens;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(BigDecimal totalCost) {
        this.totalCost = totalCost;
    }

    public String getInteractionTime() {
        return interactionTime;
    }

    public void setInteractionTime(String interactionTime) {
        this.interactionTime = interactionTime;
    }

    public boolean isLowBalance() {
        return lowBalance;
    }

    public void setLowBalance(boolean lowBalance) {
        this.lowBalance = lowBalance;
    }
}
