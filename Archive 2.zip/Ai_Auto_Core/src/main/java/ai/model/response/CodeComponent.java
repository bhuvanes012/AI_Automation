package ai.model.response;
import ai.model.CodeCompareModel;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class CodeComponent {
    @JsonProperty("package")
    private String packageName;
    @JsonProperty("language")
    private String language;
    @JsonProperty("file")
    private String file;
    @JsonProperty("className")
    private String className;
    @JsonProperty("imports")
    private List<String> imports;
    @JsonProperty("variables")
    private List<String> variables;
    @JsonProperty("methods")
    private List<MethodData> methods;

    private Boolean isClassExist = false;

    private List<CodeCompareModel> importsComparison = new ArrayList<>();
    private List<CodeCompareModel> variablesComparison = new ArrayList<>();

    public List<CodeCompareModel> getImportsComparison() {
        return importsComparison;
    }

    public void setImportsComparison(List<CodeCompareModel> importsComparison) {
        this.importsComparison = importsComparison;
    }

    public List<CodeCompareModel> getVariablesComparison() {
        return variablesComparison;
    }

    public void setVariablesComparison(List<CodeCompareModel> variablesComparison) {
        this.variablesComparison = variablesComparison;
    }

    public String getPackageName() {
        return packageName;
    }

    @com.fasterxml.jackson.annotation.JsonProperty("package")
    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public List<String> getImports() {
        return imports;
    }

    public void setImports(List<String> imports) {
        this.imports = imports;
    }

    public List<String> getVariables() {
        return variables;
    }

    public void setVariables(List<String> variables) {
        this.variables = variables;
    }

    public List<MethodData> getMethods() {
        return methods;
    }

    public void setMethods(List<MethodData> methods) {
        this.methods = methods;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Boolean getClassExist() {
        return isClassExist;
    }

    public void setClassExist(Boolean classExist) {
        isClassExist = classExist;
    }
}