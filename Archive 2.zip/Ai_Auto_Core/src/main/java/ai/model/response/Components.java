package ai.model.response;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class Components {

    @JsonProperty("POM")
    private ArrayList<CodeComponent> pom;

    @JsonProperty("StepDefinition")
    private ArrayList<CodeComponent> stepDefinition;
    @JsonProperty("features")
    private ArrayList<Feature> features;



    public ArrayList<CodeComponent> getPom() {
        return pom;
    }

    public void setPom(ArrayList<CodeComponent> pom) {
        this.pom = pom;
    }

    public ArrayList<CodeComponent> getStepDefinition() {
        return stepDefinition;
    }

    public void setStepDefinition(ArrayList<CodeComponent> stepDefinition) {
        this.stepDefinition = stepDefinition;
    }

    public List<Feature> getFeatures() {
        return features;
    }

    public void setFeatures(ArrayList<Feature> features) {
        this.features = features;
    }


}
