package ai.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Framework {
    @JsonProperty("components")
    private Components components;

    public Components getComponents() {
        return components;
    }

    public void setComponents(Components components) {
        this.components = components;
    }
}