package ai.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FrameworkDetails  {
    @JsonProperty("framework")
    private Framework framework;

    public Framework getFramework() {
        return framework;
    }

    public void setFramework(Framework framework) {
        this.framework = framework;
    }
}