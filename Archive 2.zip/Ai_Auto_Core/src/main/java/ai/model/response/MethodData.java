package ai.model.response;

import ai.model.CodeCompareModel;

public class MethodData {

    private String name;
    private String code;

    private boolean isMethodExist =false;
    private CodeCompareModel methodCode = new CodeCompareModel();

    public boolean isMethodExist() {
        return isMethodExist;
    }

    public void setMethodExist(boolean methodExist) {
        isMethodExist = methodExist;
    }

    public CodeCompareModel getMethodCode() {
        return methodCode;
    }

    public void setMethodCode(CodeCompareModel methodCode) {
        this.methodCode = methodCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}