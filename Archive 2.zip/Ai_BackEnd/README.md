# Ai_BackEnd

## Overview
- Spring Boot backend for user registration, LLM requests, and token-based billing.
- Uses SQLite for persistence and OpenAI for response generation.

## API

### `POST /api/jsScript`
Request parameters:
- `macAddress`
- `phoneNumber`
- `userName`

Behavior:
- Creates a new user if `phoneNumber` does not exist.
- New users start with a balance of `5.00`.
- If balance is `<= 0`, returns a low-balance response and skips the LLM call.
- If balance is positive, calls the LLM, calculates cost from pricing data, deducts balance, and stores one interaction record.

Response:
- Single JSON response with status, balance, encrypted LLM response, token counts, and billing details.

### `POST /api/llm`
Request parameter:
- `query`

Behavior:
- Calls OpenAI directly.
- Returns the encrypted response with token usage data.

## Database
- SQLite database file is created automatically if missing.
- Tables:
  - `users`
  - `interaction_details`
  - `pricing_details`

## Configuration
Environment variables:
- `SQLITE_DB_PATH`
- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `APP_ENCRYPTION_SECRET`
- `INPUT_TOKEN_PRICE_PER_MILLION`
- `OUTPUT_TOKEN_PRICE_PER_MILLION`
- `CACHE_TOKEN_PRICE_PER_MILLION`

## Flow
1. Validate request.
2. Find user by phone number.
3. Create user if missing.
4. Return low-balance response if balance is not positive.
5. Otherwise call LLM.
6. Read token pricing from SQLite.
7. Calculate billing cost.
8. Update balance and insert interaction details in one transaction.

## Error Handling
- Validation errors return structured JSON.
- Database failures return structured JSON.
- Configuration and external service failures return structured JSON.

## Notes
- The LLM response is encrypted before being returned.
- Logging avoids printing the raw LLM output.
