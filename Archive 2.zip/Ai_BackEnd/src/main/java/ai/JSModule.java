package ai;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class JSModule {

    public JSModule(){
        String givenDateStr = "15/06/2026";

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate givenDate =
                LocalDate.parse(givenDateStr, formatter);

        LocalDate currentDate = LocalDate.now();

        if (currentDate.isAfter(givenDate)) {
            throw new RuntimeException("Please contact the admin 'bwaran114@gmail.com'");
        }
    }


    public static String jsElementListener( ) {

        String jsElementListener = """
               // Initialise a two-slot array for the latest events
                window._eventStore = [null, null];
                
                // Click Listener
                document.addEventListener("click",function (e) {
                    let el = e.target;
                
                    const eventData = {
                        action: "click",
                        tag: el.tagName,
                        id: el.id,
                        xpath: el, // Keep your original xpath logic
                        timestamp: new Date().toISOString()
                    };
                
                    // Preserve SELECT details
                    if (el.tagName === "SELECT") {
                        const selectedOption = el.options[el.selectedIndex];
                
                        eventData.selectedOption = {
                            text: selectedOption.text,
                            value: selectedOption.value,
                            id: selectedOption.id
                        };
                
                        if (el.selectedIndex !== 0) {
                            el = selectedOption;
                        }
                    }
                
                    // Store clicked element
                    window._eventStore[0] = e.composedPath()[0];
                 
                  const link = el.closest("a[href]");
                
                     if (link) {
                         e.preventDefault();
                         setTimeout(() => {
                                         window.location.href = link.href;
                          }, 2000);
                    
                     }
                 
                    console.log("PW_EVENT::" + JSON.stringify(eventData));
                }, true);
                
                // Hover Listener
                document.addEventListener("mouseover", function (e) {
                    let el = e.target;
                
                    const hoverData = {
                        action: "hover",
                        tag: el.tagName,
                        id: el.id,
                        xpath: el, // Keep your original xpath logic
                        timestamp: new Date().toISOString()
                    };
                
                    // Store hovered element
                    window._eventStore[1] = e.composedPath()[0];
                
                    console.log("PW_HOVER::" + JSON.stringify(hoverData));
                }, true);

                """;



      return jsElementListener;
    }

    public static String jsMouseHighlight(){
        String highlightScript = """
            let highlightedElement = null;
        
            // Use composedPath() to get the actual element that triggered the event
            document.addEventListener("mouseover", (e) => {
                const el = e.composedPath()[0];
        
                if (highlightedElement !== el) {
                    if (highlightedElement) {
                        highlightedElement.style.outline = "";
                    }
        
                    highlightedElement = el;
                    highlightedElement.style.outline = "3px solid red";
                }
            }, true);
        
            document.addEventListener("mouseout", (e) => {
                const el = e.composedPath()[0];
        
                if (el === highlightedElement) {
                    highlightedElement.style.outline = "";
                    highlightedElement = null;
                }
            }, true);
            """;
        return highlightScript;
    }

    public static String jsListOfXpathGenerator(){
        String listOfXpathJs =
                "var el = arguments[0];" +
                        "var txt = arguments[1];" +
                        "var result = [];" +

                        // Add xpath only if unique and identifies only this element
                        "function addXpath(xp) {" +
                        "   if(!xp || xp.trim() === '') return;" +
                        "   try {" +
                        "       var nodes = document.evaluate(" +
                        "           xp," +
                        "           document," +
                        "           null," +
                        "           XPathResult.ORDERED_NODE_SNAPSHOT_TYPE," +
                        "           null" +
                        "       );" +
                        "       if(nodes.snapshotLength === 1) {" +
                        "           var found = nodes.snapshotItem(0);" +
                        "           if(found === el && result.indexOf(xp) === -1) {" +
                        "               result.push(xp);" +
                        "           }" +
                        "       }" +
                        "   } catch(e) {}" +
                        "}" +

                        // Get index under a parent xpath
                        "function getXpathIndex(baseXpath, tag, element) {" +
                        "   try {" +
                        "       var searchXpath = baseXpath + '//' + tag;" +
                        "       var nodes = document.evaluate(" +
                        "           searchXpath," +
                        "           document," +
                        "           null," +
                        "           XPathResult.ORDERED_NODE_SNAPSHOT_TYPE," +
                        "           null" +
                        "       );" +
                        "       for(var i = 0; i < nodes.snapshotLength; i++) {" +
                        "           if(nodes.snapshotItem(i) === element) {" +
                        "               return i + 1;" +
                        "           }" +
                        "       }" +
                        "   } catch(e) {}" +
                        "   return 1;" +
                        "}" +

                        "var tag = el.tagName.toLowerCase();" +

                        // 1. ID
                        "if(el.id && el.id.trim() !== '') {" +
                        "   addXpath('//*[@id=\\'' + el.id + '\\']');" +
                        "}" +

                        // 2. ALL ATTRIBUTES
                        "function addAttrXpath(attrName) {" +
                        "   var val = el.getAttribute(attrName);" +
                        "   if(val && val.trim() !== '') {" +

                        // Exact match
                        "       addXpath('//' + tag + '[@' + attrName + '=\\'' + val + '\\']');" +

                        // Contains match
                        "       addXpath('//' + tag + '[contains(@' + attrName + ',\\'' + val + '\\')]');" +

                        // For class attribute generate one xpath per class
                        "       if(attrName === 'class') {" +
                        "           var classes = val.trim().split(/\\s+/);" +
                        "           for(var i=0;i<classes.length;i++){" +
                        "               if(classes[i].trim() !== ''){" +
                        "                   addXpath('//' + tag + '[contains(@class,\\'' + classes[i] + '\\')]');" +
                        "               }" +
                        "           }" +
                        "       }" +
                        "   }" +
                        "}" +

                        // Iterate every attribute
                        "for(var i=0;i<el.attributes.length;i++){" +
                        "   addAttrXpath(el.attributes[i].name);" +
                        "}" +

                        // 3. Parent IDs
                        "var current = el.parentElement;" +
                        "while(current) {" +
                        "   if(current.id && current.id.trim() !== '') {" +
                        "       var base = '//*[@id=\\'' + current.id + '\\']';" +

                        "       if(txt && txt.trim() !== '') {" +
                        "           addXpath(base + '//' + tag + '[contains(text(),\\'' + txt + '\\')]');" +
                        "           addXpath(base + '//*[contains(text(),\\'' + txt + '\\')]');" +
                        "       } else {" +
                        "           var idx = getXpathIndex(base, tag, el);" +
                        "           addXpath('(' + base + '//' + tag + ')[' + idx + ']');" +
                        "       }" +
                        "   }" +
                        "   current = current.parentElement;" +
                        "}" +

                        // 4. Text based
                        "if(txt && txt.trim() !== '') {" +
                        "   addXpath('//' + tag + '[contains(normalize-space(text()),\\'' + txt + '\\')]');" +
                        "}" +

                        // 5. Absolute index
                        "var all = document.getElementsByTagName(tag);" +
                        "for(var j=0;j<all.length;j++){" +
                        "   if(all[j]===el){" +
                        "       addXpath('(//' + tag + ')[' + (j+1) + ']');" +
                        "       break;" +
                        "   }" +
                        "}" +

                        "return result;";
        return listOfXpathJs;
    }

}
