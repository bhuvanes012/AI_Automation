package ai;

import ai.config.OpenAiProperties;
import ai.dto.LlmResponse;
import ai.exception.ConfigurationException;
import ai.exception.ExternalServiceException;
import ai.util.CryptoUtil;
import ai.utils.Helper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Service
public class LLMCall {

    private static final Logger log = LoggerFactory.getLogger(LLMCall.class);

    private final OpenAiProperties openAiProperties;
    private final HttpClient httpClient;

    public LLMCall(OpenAiProperties openAiProperties) {
        this.openAiProperties = openAiProperties;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }



    public LlmResponse generate(String promptContext) {
        String apiKey = openAiProperties.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            throw new ConfigurationException("OpenAI API key is not configured");
        }
        String model = openAiProperties.getModel();
        if (model == null || model.isBlank()) {
            model = "gpt-5.6-Luna";
        }

        String encryptionSecret = openAiProperties.getResponseEncryptionSecret();
        if (encryptionSecret == null || encryptionSecret.isBlank()) {
            encryptionSecret = "change-this-secret";
        }

        String systemMessage = Helper.readFile("systemMessage.txt");
        String prompt = systemMessage.replace("{testSteps}", promptContext);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.addProperty("input", prompt);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.openai.com/v1/responses"))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new ExternalServiceException(
                        "OpenAI request failed with status " + response.statusCode() + ": " + response.body(),
                        null
                );
            }

            JsonObject jsonObject = JsonParser.parseString(response.body()).getAsJsonObject();
            String text = extractText(jsonObject);
            long inputTokens = extractLong(jsonObject, "usage", "input_tokens");
            long outputTokens = extractLong(jsonObject, "usage", "output_tokens");
            long cacheTokens = extractCachedTokens(jsonObject);
            String encryptedResponse = CryptoUtil.encrypt(text, encryptionSecret);

            log.info("OpenAI response received: inputTokens={}, outputTokens={}, cacheTokens={}", inputTokens, outputTokens, cacheTokens);

            return new LlmResponse(
                    null,
                    null,
                    null,
                    null,
                    encryptedResponse,
                    inputTokens,
                    outputTokens,
                    cacheTokens,
                    null,
                    null,
                    false
            );
        } catch (Exception ex) {
            if (ex instanceof ExternalServiceException) {
                throw (ExternalServiceException) ex;
            }
            throw new ExternalServiceException("Failed to call OpenAI", ex);
        }
    }

    private String extractText(JsonObject jsonObject) {
        JsonArray output = jsonObject.getAsJsonArray("output");
        if (output == null) {
            return "";
        }

        StringBuilder builder = new StringBuilder();
        for (JsonElement out : output) {
            JsonObject outputDetails = out.getAsJsonObject();
            JsonArray contentArray = outputDetails.getAsJsonArray("content");
            if (contentArray == null) {
                continue;
            }

            for (JsonElement content : contentArray) {
                JsonObject contentDetails = content.getAsJsonObject();
                if (contentDetails.has("text")) {
                    builder.append(contentDetails.get("text").getAsString());
                }
            }
        }
        return builder.toString();
    }

    private long extractLong(JsonObject jsonObject, String outerKey, String innerKey) {
        JsonObject outer = jsonObject.getAsJsonObject(outerKey);
        if (outer == null || !outer.has(innerKey) || outer.get(innerKey).isJsonNull()) {
            return 0L;
        }
        return outer.get(innerKey).getAsLong();
    }

    private long extractCachedTokens(JsonObject jsonObject) {
        JsonObject usage = jsonObject.getAsJsonObject("usage");
        if (usage == null) {
            return 0L;
        }

        JsonObject inputDetails = usage.getAsJsonObject("input_tokens_details");
        if (inputDetails != null && inputDetails.has("cached_tokens") && !inputDetails.get("cached_tokens").isJsonNull()) {
            return inputDetails.get("cached_tokens").getAsLong();
        }

        if (inputDetails != null && inputDetails.has("cache_tokens") && !inputDetails.get("cache_tokens").isJsonNull()) {
            return inputDetails.get("cache_tokens").getAsLong();
        }

        return 0L;
    }
}
