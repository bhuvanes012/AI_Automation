package ai.config;

import org.sqlite.SQLiteDataSource;
import org.sqlite.SQLiteConfig;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
@EnableConfigurationProperties({SqliteProperties.class, OpenAiProperties.class, PricingProperties.class})
public class DatabaseConfig {

    @Bean
    public DataSource dataSource(SqliteProperties sqliteProperties) throws IOException {
        Path dbPath = resolveDbPath(sqliteProperties.getDbPath());
        Path parent = dbPath.getParent();

        if (parent != null) {
            Files.createDirectories(parent);
        }
        if (Files.notExists(dbPath)) {
            try {
                Files.createFile(dbPath);
            } catch (FileAlreadyExistsException ignored) {
                // Another startup thread or process created it first.
            }
        }

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl("jdbc:sqlite:" + dbPath.toAbsolutePath());
        SQLiteConfig config = new SQLiteConfig();
        config.enforceForeignKeys(true);
        dataSource.setConfig(config);
        return dataSource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public PlatformTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    private Path resolveDbPath(String dbPath) {
        String resolvedPath = StringUtils.hasText(dbPath) ? dbPath : "./data/ai-backend.db";
        return Paths.get(resolvedPath).normalize();
    }
}
