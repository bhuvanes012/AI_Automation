package ai.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.openai")
public class OpenAiProperties {
    private String apiKey;
    private String model;
    private String responseEncryptionSecret;

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getResponseEncryptionSecret() {
        return responseEncryptionSecret;
    }

    public void setResponseEncryptionSecret(String responseEncryptionSecret) {
        this.responseEncryptionSecret = responseEncryptionSecret;
    }
}
