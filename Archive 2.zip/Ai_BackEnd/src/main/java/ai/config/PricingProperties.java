package ai.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;

@ConfigurationProperties(prefix = "app.pricing")
public class PricingProperties {
    private BigDecimal inputTokenPricePerMillion = BigDecimal.ZERO;
    private BigDecimal outputTokenPricePerMillion = BigDecimal.ZERO;
    private BigDecimal cacheTokenPricePerMillion = BigDecimal.ZERO;

    public BigDecimal getInputTokenPricePerMillion() {
        return inputTokenPricePerMillion;
    }

    public void setInputTokenPricePerMillion(BigDecimal inputTokenPricePerMillion) {
        this.inputTokenPricePerMillion = inputTokenPricePerMillion;
    }

    public BigDecimal getOutputTokenPricePerMillion() {
        return outputTokenPricePerMillion;
    }

    public void setOutputTokenPricePerMillion(BigDecimal outputTokenPricePerMillion) {
        this.outputTokenPricePerMillion = outputTokenPricePerMillion;
    }

    public BigDecimal getCacheTokenPricePerMillion() {
        return cacheTokenPricePerMillion;
    }

    public void setCacheTokenPricePerMillion(BigDecimal cacheTokenPricePerMillion) {
        this.cacheTokenPricePerMillion = cacheTokenPricePerMillion;
    }
}
