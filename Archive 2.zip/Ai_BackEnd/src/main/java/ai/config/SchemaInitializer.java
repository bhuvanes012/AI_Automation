package ai.config;

import ai.repository.PricingRepository;
import ai.utils.Helper;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;

@Component
public class SchemaInitializer {

    private final JdbcTemplate jdbcTemplate;
    private final PricingRepository pricingRepository;
    private final PricingProperties pricingProperties;

    public SchemaInitializer(JdbcTemplate jdbcTemplate,
                             PricingRepository pricingRepository,
                             PricingProperties pricingProperties) {
        this.jdbcTemplate = jdbcTemplate;
        this.pricingRepository = pricingRepository;
        this.pricingProperties = pricingProperties;
    }

    @PostConstruct
    public void initialize() {
        String schemaSql = Helper.readFile("db/schema.sql");
        for (String statement : schemaSql.split(";")) {
            String trimmed = statement.trim();
            if (!trimmed.isEmpty()) {
                jdbcTemplate.execute(trimmed);
            }
        }

        pricingRepository.seedDefaultPricingIfMissing(
                pricingProperties.getInputTokenPricePerMillion(),
                pricingProperties.getOutputTokenPricePerMillion(),
                pricingProperties.getCacheTokenPricePerMillion()
        );
    }
}
