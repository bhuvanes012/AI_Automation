package ai.controllers;

import ai.dto.JsScriptRequest;
import ai.dto.JsScriptResponse;
import ai.dto.LlmResponse;
import ai.dto.PricingUpdateRequest;
import ai.dto.PricingUpdateResponse;
import ai.service.JsScriptService;
import ai.service.LlmWorkflowService;
import ai.service.PricingUpdateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@Validated
public class JsController {

    private static final Logger log = LoggerFactory.getLogger(JsController.class);

    private final JsScriptService jsScriptService;
    private final LlmWorkflowService llmWorkflowService;
    private final PricingUpdateService pricingUpdateService;

    public JsController(JsScriptService jsScriptService,
                        LlmWorkflowService llmWorkflowService,
                        PricingUpdateService pricingUpdateService) {
        this.jsScriptService = jsScriptService;
        this.llmWorkflowService = llmWorkflowService;
        this.pricingUpdateService = pricingUpdateService;
    }

    @PostMapping("/jsScript")
    public ResponseEntity<JsScriptResponse> jsScript(@RequestParam @NotBlank String macAddress,
                                                     @RequestParam @NotBlank String phoneNumber,
                                                     @RequestParam @NotBlank String userName) {
        JsScriptRequest request = new JsScriptRequest();
        request.setMacAddress(macAddress);
        request.setPhoneNumber(phoneNumber);
        request.setUserName(userName);
        log.info("Processing /api/jsScript for phoneNumber={}", request.getPhoneNumber());
        return ResponseEntity.ok(jsScriptService.process(request));
    }

    @PostMapping("/llm")
    public ResponseEntity<LlmResponse> llmCall(@RequestParam @NotBlank String phoneNumber,
                                               @RequestParam @NotBlank String query) {
        log.info("Processing /api/llm request for phoneNumber={}", phoneNumber);
        return ResponseEntity.ok(llmWorkflowService.process(phoneNumber, query));
    }

    @PostMapping("/pricing")
    public ResponseEntity<PricingUpdateResponse> updatePricing(@Valid @RequestBody PricingUpdateRequest request) {
        log.info("Processing /api/pricing update");
        return ResponseEntity.ok(pricingUpdateService.updatePricing(request));
    }
}
