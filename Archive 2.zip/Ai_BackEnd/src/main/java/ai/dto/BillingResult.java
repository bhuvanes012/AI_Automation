package ai.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class BillingResult {
    private final BigDecimal balanceAmount;
    private final BigDecimal totalCost;
    private final LocalDateTime interactionTime;

    public BillingResult(BigDecimal balanceAmount, BigDecimal totalCost, LocalDateTime interactionTime) {
        this.balanceAmount = balanceAmount;
        this.totalCost = totalCost;
        this.interactionTime = interactionTime;
    }

    public BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }

    public LocalDateTime getInteractionTime() {
        return interactionTime;
    }
}
