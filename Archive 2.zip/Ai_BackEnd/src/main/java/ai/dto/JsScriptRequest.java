package ai.dto;

import jakarta.validation.constraints.NotBlank;

public class JsScriptRequest {

    @NotBlank
    private String macAddress;

    @NotBlank
    private String phoneNumber;

    @NotBlank
    private String userName;

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
