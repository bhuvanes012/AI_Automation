package ai.dto;

public class LlmResponse {
    private final String status;
    private final String message;
    private final String phoneNumber;
    private final java.math.BigDecimal balanceAmount;
    private final String encryptedResponse;
    private final long inputTokens;
    private final long outputTokens;
    private final long cacheTokens;
    private final java.math.BigDecimal totalCost;
    private final java.time.LocalDateTime interactionTime;
    private final boolean lowBalance;

    public LlmResponse(String status,
                       String message,
                       String phoneNumber,
                       java.math.BigDecimal balanceAmount,
                       String encryptedResponse,
                       long inputTokens,
                       long outputTokens,
                       long cacheTokens,
                       java.math.BigDecimal totalCost,
                       java.time.LocalDateTime interactionTime,
                       boolean lowBalance) {
        this.status = status;
        this.message = message;
        this.phoneNumber = phoneNumber;
        this.balanceAmount = balanceAmount;
        this.encryptedResponse = encryptedResponse;
        this.inputTokens = inputTokens;
        this.outputTokens = outputTokens;
        this.cacheTokens = cacheTokens;
        this.totalCost = totalCost;
        this.interactionTime = interactionTime;
        this.lowBalance = lowBalance;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public java.math.BigDecimal getBalanceAmount() {
        return balanceAmount;
    }

    public String getEncryptedResponse() {
        return encryptedResponse;
    }

    public long getInputTokens() {
        return inputTokens;
    }

    public long getOutputTokens() {
        return outputTokens;
    }

    public long getCacheTokens() {
        return cacheTokens;
    }

    public java.math.BigDecimal getTotalCost() {
        return totalCost;
    }

    public java.time.LocalDateTime getInteractionTime() {
        return interactionTime;
    }

    public boolean isLowBalance() {
        return lowBalance;
    }
}
