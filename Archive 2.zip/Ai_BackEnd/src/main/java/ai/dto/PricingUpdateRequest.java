package ai.dto;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class PricingUpdateRequest {
    @NotNull
    private BigDecimal inputTokenPricePerMillion;

    @NotNull
    private BigDecimal outputTokenPricePerMillion;

    @NotNull
    private BigDecimal cacheTokenPricePerMillion;

    public BigDecimal getInputTokenPricePerMillion() {
        return inputTokenPricePerMillion;
    }

    public void setInputTokenPricePerMillion(BigDecimal inputTokenPricePerMillion) {
        this.inputTokenPricePerMillion = inputTokenPricePerMillion;
    }

    public BigDecimal getOutputTokenPricePerMillion() {
        return outputTokenPricePerMillion;
    }

    public void setOutputTokenPricePerMillion(BigDecimal outputTokenPricePerMillion) {
        this.outputTokenPricePerMillion = outputTokenPricePerMillion;
    }

    public BigDecimal getCacheTokenPricePerMillion() {
        return cacheTokenPricePerMillion;
    }

    public void setCacheTokenPricePerMillion(BigDecimal cacheTokenPricePerMillion) {
        this.cacheTokenPricePerMillion = cacheTokenPricePerMillion;
    }
}
