package ai.dto;

import java.math.BigDecimal;

public class PricingUpdateResponse {
    private String status;
    private String message;
    private BigDecimal inputTokenPricePerMillion;
    private BigDecimal outputTokenPricePerMillion;
    private BigDecimal cacheTokenPricePerMillion;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public BigDecimal getInputTokenPricePerMillion() {
        return inputTokenPricePerMillion;
    }

    public void setInputTokenPricePerMillion(BigDecimal inputTokenPricePerMillion) {
        this.inputTokenPricePerMillion = inputTokenPricePerMillion;
    }

    public BigDecimal getOutputTokenPricePerMillion() {
        return outputTokenPricePerMillion;
    }

    public void setOutputTokenPricePerMillion(BigDecimal outputTokenPricePerMillion) {
        this.outputTokenPricePerMillion = outputTokenPricePerMillion;
    }

    public BigDecimal getCacheTokenPricePerMillion() {
        return cacheTokenPricePerMillion;
    }

    public void setCacheTokenPricePerMillion(BigDecimal cacheTokenPricePerMillion) {
        this.cacheTokenPricePerMillion = cacheTokenPricePerMillion;
    }
}
