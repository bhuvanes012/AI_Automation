package ai.dto;

import ai.entity.UserAccount;

public class UserResolutionResult {
    private final UserAccount userAccount;
    private final boolean newUser;

    public UserResolutionResult(UserAccount userAccount, boolean newUser) {
        this.userAccount = userAccount;
        this.newUser = newUser;
    }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    public boolean isNewUser() {
        return newUser;
    }
}
