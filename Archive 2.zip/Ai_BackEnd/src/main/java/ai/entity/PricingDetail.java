package ai.entity;

import java.math.BigDecimal;

public class PricingDetail {
    private Long id;
    private BigDecimal inputTokenPricePerMillion;
    private BigDecimal outputTokenPricePerMillion;
    private BigDecimal cacheTokenPricePerMillion;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getInputTokenPricePerMillion() {
        return inputTokenPricePerMillion;
    }

    public void setInputTokenPricePerMillion(BigDecimal inputTokenPricePerMillion) {
        this.inputTokenPricePerMillion = inputTokenPricePerMillion;
    }

    public BigDecimal getOutputTokenPricePerMillion() {
        return outputTokenPricePerMillion;
    }

    public void setOutputTokenPricePerMillion(BigDecimal outputTokenPricePerMillion) {
        this.outputTokenPricePerMillion = outputTokenPricePerMillion;
    }

    public BigDecimal getCacheTokenPricePerMillion() {
        return cacheTokenPricePerMillion;
    }

    public void setCacheTokenPricePerMillion(BigDecimal cacheTokenPricePerMillion) {
        this.cacheTokenPricePerMillion = cacheTokenPricePerMillion;
    }
}
