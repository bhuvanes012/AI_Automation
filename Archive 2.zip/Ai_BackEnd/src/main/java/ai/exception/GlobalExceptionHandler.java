package ai.exception;

import ai.dto.ApiErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.time.LocalDateTime;


@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler({BindException.class, MethodArgumentNotValidException.class})
    public ResponseEntity<ApiErrorResponse> handleValidation(Exception exception, HttpServletRequest request) {
        log.warn("Validation failed: {}", exception.getMessage());
        return build(HttpStatus.BAD_REQUEST, "Validation failed", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiErrorResponse> handleConstraintViolation(ConstraintViolationException exception, HttpServletRequest request) {
        log.warn("Constraint violation: {}", exception.getMessage());
        return build(HttpStatus.BAD_REQUEST, "Validation failed", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<ApiErrorResponse> handleDataAccess(DataAccessException exception, HttpServletRequest request) {
        log.error("Database error", exception);
        Throwable cause = exception.getMostSpecificCause();
        String message = cause != null ? cause.getMessage() : exception.getMessage();
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Database error", message, request.getRequestURI());
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<ApiErrorResponse> handleIllegalState(IllegalStateException exception, HttpServletRequest request) {
        log.error("Application error", exception);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Application error", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ConfigurationException.class)
    public ResponseEntity<ApiErrorResponse> handleConfiguration(ConfigurationException exception, HttpServletRequest request) {
        log.error("Configuration error", exception);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Configuration error", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ExternalServiceException.class)
    public ResponseEntity<ApiErrorResponse> handleExternalService(ExternalServiceException exception, HttpServletRequest request) {
        log.error("External service error", exception);
        return build(HttpStatus.BAD_GATEWAY, "External service error", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleNotFound(ResourceNotFoundException exception, HttpServletRequest request) {
        log.error("Resource not found", exception);
        return build(HttpStatus.NOT_FOUND, "Resource not found", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> handleGeneric(Exception exception, HttpServletRequest request) {
        log.error("Unexpected error", exception);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error", exception.getMessage(), request.getRequestURI());
    }

    private ResponseEntity<ApiErrorResponse> build(HttpStatus status, String error, String message, String path) {
        return ResponseEntity.status(status).body(new ApiErrorResponse(
                LocalDateTime.now(),
                status.value(),
                error,
                message,
                path
        ));
    }
}
