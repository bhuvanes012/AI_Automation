package ai.model;

public class JSModel {

    public  String jsElementListener="";
    public  String mouseHighlight ="";
    public  String jsListOfXpathGenerator ="";

    public String getJsElementListener() {
        return jsElementListener;
    }

    public void setJsElementListener(String jsElementListener) {
        this.jsElementListener = jsElementListener;
    }

    public String getMouseHighlight() {
        return mouseHighlight;
    }

    public void setMouseHighlight(String mouseHighlight) {
        this.mouseHighlight = mouseHighlight;
    }

    public String getJsListOfXpathGenerator() {
        return jsListOfXpathGenerator;
    }

    public void setJsListOfXpathGenerator(String jsListOfXpathGenerator) {
        this.jsListOfXpathGenerator = jsListOfXpathGenerator;
    }
}
