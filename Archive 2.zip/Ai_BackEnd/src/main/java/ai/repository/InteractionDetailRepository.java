package ai.repository;

import ai.entity.InteractionDetail;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class InteractionDetailRepository {

    private static final String INSERT_INTERACTION = "INSERT INTO interaction_details (phone_number, interaction_time, input_tokens, output_tokens, cache_tokens, current_balance) VALUES (?, ?, ?, ?, ?, ?)";

    private final JdbcTemplate jdbcTemplate;

    public InteractionDetailRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insert(InteractionDetail interactionDetail) {
        jdbcTemplate.update(INSERT_INTERACTION,
                interactionDetail.getPhoneNumber(),
                interactionDetail.getInteractionTime().toString(),
                interactionDetail.getInputTokens(),
                interactionDetail.getOutputTokens(),
                interactionDetail.getCacheTokens(),
                interactionDetail.getCurrentBalance());
    }
}
