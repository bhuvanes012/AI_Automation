package ai.repository;

import ai.entity.PricingDetail;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

@Repository
public class PricingRepository {

    private static final String FIND_CURRENT = "SELECT id, input_token_price_per_million, output_token_price_per_million, cache_token_price_per_million FROM pricing_details WHERE id = 1";
    private static final String SEED_PRICING = "INSERT OR IGNORE INTO pricing_details (id, input_token_price_per_million, output_token_price_per_million, cache_token_price_per_million) VALUES (1, ?, ?, ?)";
    private static final String UPDATE_PRICING = "UPDATE pricing_details SET input_token_price_per_million = ?, output_token_price_per_million = ?, cache_token_price_per_million = ? WHERE id = 1";

    private final JdbcTemplate jdbcTemplate;

    public PricingRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Optional<PricingDetail> findCurrentPricing() {
        return jdbcTemplate.query(FIND_CURRENT, rs -> rs.next() ? Optional.of(mapPricing(rs)) : Optional.empty());
    }

    public void seedDefaultPricingIfMissing(BigDecimal inputPrice, BigDecimal outputPrice, BigDecimal cachePrice) {
        jdbcTemplate.update(SEED_PRICING, inputPrice, outputPrice, cachePrice);
    }

    public int updatePricingDetails(BigDecimal inputPrice, BigDecimal outputPrice, BigDecimal cachePrice) {
        return jdbcTemplate.update(UPDATE_PRICING, inputPrice, outputPrice, cachePrice);
    }

    private PricingDetail mapPricing(ResultSet rs) throws SQLException {
        PricingDetail pricing = new PricingDetail();
        pricing.setId(rs.getLong("id"));
        pricing.setInputTokenPricePerMillion(rs.getBigDecimal("input_token_price_per_million"));
        pricing.setOutputTokenPricePerMillion(rs.getBigDecimal("output_token_price_per_million"));
        pricing.setCacheTokenPricePerMillion(rs.getBigDecimal("cache_token_price_per_million"));
        return pricing;
    }
}
