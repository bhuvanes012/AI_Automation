package ai.repository;

import ai.entity.UserAccount;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public class UserRepository {

    private static final String FIND_BY_PHONE = "SELECT phone_number, mac_address, user_name, balance_amount, last_modified_date FROM users WHERE phone_number = ?";
    private static final String INSERT_USER = "INSERT OR IGNORE INTO users (phone_number, mac_address, user_name, balance_amount, last_modified_date) VALUES (?, ?, ?, ?, ?)";
    private static final String UPDATE_BALANCE = "UPDATE users SET balance_amount = ?, last_modified_date = ? WHERE phone_number = ?";

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Optional<UserAccount> findByPhoneNumber(String phoneNumber) {
        return jdbcTemplate.query(FIND_BY_PHONE, rs -> rs.next() ? Optional.of(mapUser(rs)) : Optional.empty(), phoneNumber);
    }

    public boolean insert(UserAccount userAccount) {
        int updated = jdbcTemplate.update(INSERT_USER,
                userAccount.getPhoneNumber(),
                userAccount.getMacAddress(),
                userAccount.getUserName(),
                userAccount.getBalanceAmount(),
                toTimestamp(userAccount.getLastModifiedDate()));
        return updated > 0;
    }

    public void updateBalance(String phoneNumber, BigDecimal balanceAmount, LocalDateTime lastModifiedDate) {
        jdbcTemplate.update(UPDATE_BALANCE,
                balanceAmount,
                toTimestamp(lastModifiedDate),
                phoneNumber);
    }

    private UserAccount mapUser(ResultSet rs) throws SQLException {
        UserAccount user = new UserAccount();
        user.setPhoneNumber(rs.getString("phone_number"));
        user.setMacAddress(rs.getString("mac_address"));
        user.setUserName(rs.getString("user_name"));
        user.setBalanceAmount(rs.getBigDecimal("balance_amount"));
        user.setLastModifiedDate(fromTimestamp(rs.getString("last_modified_date")));
        return user;
    }

    private String toTimestamp(LocalDateTime dateTime) {
        return dateTime.toString();
    }

    private LocalDateTime fromTimestamp(String timestamp) {
        return LocalDateTime.parse(timestamp);
    }
}
