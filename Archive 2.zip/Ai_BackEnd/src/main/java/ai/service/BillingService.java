package ai.service;

import ai.dto.BillingResult;
import ai.dto.LlmResponse;
import ai.entity.InteractionDetail;
import ai.entity.PricingDetail;
import ai.entity.UserAccount;
import ai.repository.InteractionDetailRepository;
import ai.repository.UserRepository;
import ai.util.BillingCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Service
public class BillingService {

    private static final Logger log = LoggerFactory.getLogger(BillingService.class);

    private final UserRepository userRepository;
    private final InteractionDetailRepository interactionDetailRepository;

    public BillingService(UserRepository userRepository,
                          InteractionDetailRepository interactionDetailRepository) {
        this.userRepository = userRepository;
        this.interactionDetailRepository = interactionDetailRepository;
    }

    @Transactional
    public BillingResult applyBilling(String phoneNumber, LlmResponse llmResponse, PricingDetail pricingDetail) {
        UserAccount userAccount = userRepository.findByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new IllegalStateException("User not found for billing"));

        BigDecimal totalCost = BillingCalculator.calculateTotalCost(
                llmResponse.getInputTokens(),
                llmResponse.getOutputTokens(),
                llmResponse.getCacheTokens(),
                pricingDetail
        );

        BigDecimal updatedBalance = userAccount.getBalanceAmount()
                .subtract(totalCost)
                .setScale(6, RoundingMode.HALF_UP);

        LocalDateTime now = LocalDateTime.now();
        userRepository.updateBalance(phoneNumber, updatedBalance, now);

        InteractionDetail interactionDetail = new InteractionDetail();
        interactionDetail.setPhoneNumber(phoneNumber);
        interactionDetail.setInteractionTime(now);
        interactionDetail.setInputTokens(llmResponse.getInputTokens());
        interactionDetail.setOutputTokens(llmResponse.getOutputTokens());
        interactionDetail.setCacheTokens(llmResponse.getCacheTokens());
        interactionDetail.setCurrentBalance(updatedBalance);
        interactionDetailRepository.insert(interactionDetail);

        log.info("Billed phoneNumber={} cost={} newBalance={}", phoneNumber, totalCost, updatedBalance);

        return new BillingResult(updatedBalance, totalCost, now);
    }
}
