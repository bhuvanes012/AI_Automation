package ai.service;

import ai.dto.JsScriptRequest;
import ai.dto.JsScriptResponse;
import ai.dto.UserResolutionResult;
import ai.JSModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class JsScriptService {

    private static final Logger log = LoggerFactory.getLogger(JsScriptService.class);

    private final UserService userService;

    public JsScriptService(UserService userService) {
        this.userService = userService;
    }

    public JsScriptResponse process(JsScriptRequest request) {
        UserResolutionResult userResolutionResult = userService.findOrCreateUser(request);
        JsScriptResponse response = baseResponse(request, userResolutionResult);

        if (userResolutionResult.getUserAccount().getBalanceAmount().compareTo(BigDecimal.ZERO) <= 0) {
            log.info("Low balance for phoneNumber={}", request.getPhoneNumber());
            response.setStatus("LOW_BALANCE");
            response.setMessage("Balance amount is insufficient to process the request.");
            response.setLowBalance(true);
            return response;
        }

        response.setStatus("SUCCESS");
        response.setMessage("JS scripts returned successfully.");
        response.setLowBalance(false);
        response.setJsElementListener(JSModule.jsElementListener());
        response.setMouseHighlight(JSModule.jsMouseHighlight());
        response.setJsListOfXpathGenerator(JSModule.jsListOfXpathGenerator());
        return response;
    }

    private JsScriptResponse baseResponse(JsScriptRequest request, UserResolutionResult userResolutionResult) {
        JsScriptResponse response = new JsScriptResponse();
        response.setPhoneNumber(request.getPhoneNumber());
        response.setUserName(request.getUserName());
        response.setMacAddress(request.getMacAddress());
        response.setNewUser(userResolutionResult.isNewUser());
        response.setBalanceAmount(userResolutionResult.getUserAccount().getBalanceAmount());
        return response;
    }
}
