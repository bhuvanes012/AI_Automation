package ai.service;

import ai.LLMCall;
import ai.dto.BillingResult;
import ai.dto.LlmResponse;
import ai.entity.PricingDetail;
import ai.entity.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LlmWorkflowService {

    private static final Logger log = LoggerFactory.getLogger(LlmWorkflowService.class);

    private final UserService userService;
    private final PricingService pricingService;
    private final BillingService billingService;
    private final LLMCall llmCall;

    public LlmWorkflowService(UserService userService,
                              PricingService pricingService,
                              BillingService billingService,
                              LLMCall llmCall) {
        this.userService = userService;
        this.pricingService = pricingService;
        this.billingService = billingService;
        this.llmCall = llmCall;
    }

    public LlmResponse process(String phoneNumber, String query) {
        UserAccount userAccount = userService.findExistingUser(phoneNumber);

        if (userAccount.getBalanceAmount() == null || userAccount.getBalanceAmount().doubleValue() == 0.0d) {
            log.info("Low balance for phoneNumber={}", phoneNumber);
            return new LlmResponse(
                    "LOW_BALANCE",
                    "Balance amount is insufficient to process the request.",
                    phoneNumber,
                    userAccount.getBalanceAmount(),
                    null,
                    0L,
                    0L,
                    0L,
                    null,
                    null,
                    true
            );
        }

        PricingDetail pricingDetail = pricingService.getCurrentPricing();
        LlmResponse llmResponse = llmCall.generate(query);
        BillingResult billingResult = billingService.applyBilling(phoneNumber, llmResponse, pricingDetail);

        log.info("Processed LLM request for phoneNumber={} inputTokens={} outputTokens={} cacheTokens={}",
                phoneNumber,
                llmResponse.getInputTokens(),
                llmResponse.getOutputTokens(),
                llmResponse.getCacheTokens());

        return new LlmResponse(
                "SUCCESS",
                "LLM request processed successfully.",
                phoneNumber,
                billingResult.getBalanceAmount(),
                llmResponse.getEncryptedResponse(),
                llmResponse.getInputTokens(),
                llmResponse.getOutputTokens(),
                llmResponse.getCacheTokens(),
                billingResult.getTotalCost(),
                billingResult.getInteractionTime(),
                false
        );
    }
}
