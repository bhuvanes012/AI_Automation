package ai.service;

import ai.entity.PricingDetail;
import ai.exception.ConfigurationException;
import ai.repository.PricingRepository;
import org.springframework.stereotype.Service;

@Service
public class PricingService {

    private final PricingRepository pricingRepository;

    public PricingService(PricingRepository pricingRepository) {
        this.pricingRepository = pricingRepository;
    }

    public PricingDetail getCurrentPricing() {
        return pricingRepository.findCurrentPricing()
                .orElseThrow(() -> new ConfigurationException("Pricing details are not configured"));
    }
}
