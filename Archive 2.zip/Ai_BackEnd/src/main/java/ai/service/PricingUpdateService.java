package ai.service;

import ai.dto.PricingUpdateRequest;
import ai.dto.PricingUpdateResponse;
import ai.repository.PricingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PricingUpdateService {

    private static final Logger log = LoggerFactory.getLogger(PricingUpdateService.class);

    private final PricingRepository pricingRepository;

    public PricingUpdateService(PricingRepository pricingRepository) {
        this.pricingRepository = pricingRepository;
    }

    @Transactional
    public PricingUpdateResponse updatePricing(PricingUpdateRequest request) {
        int updatedRows = pricingRepository.updatePricingDetails(
                request.getInputTokenPricePerMillion(),
                request.getOutputTokenPricePerMillion(),
                request.getCacheTokenPricePerMillion()
        );

        if (updatedRows == 0) {
            pricingRepository.seedDefaultPricingIfMissing(
                    request.getInputTokenPricePerMillion(),
                    request.getOutputTokenPricePerMillion(),
                    request.getCacheTokenPricePerMillion()
            );
            updatedRows = 1;
        }

        log.info("Updated pricing_details row(s)={}", updatedRows);

        PricingUpdateResponse response = new PricingUpdateResponse();
        response.setStatus("SUCCESS");
        response.setMessage("Pricing details updated successfully.");
        response.setInputTokenPricePerMillion(request.getInputTokenPricePerMillion());
        response.setOutputTokenPricePerMillion(request.getOutputTokenPricePerMillion());
        response.setCacheTokenPricePerMillion(request.getCacheTokenPricePerMillion());
        return response;
    }
}
