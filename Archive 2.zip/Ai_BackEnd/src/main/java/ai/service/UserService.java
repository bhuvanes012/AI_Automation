package ai.service;

import ai.dto.JsScriptRequest;
import ai.dto.UserResolutionResult;
import ai.entity.UserAccount;
import ai.exception.ResourceNotFoundException;
import ai.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    private static final BigDecimal STARTING_BALANCE = new BigDecimal("5.00");

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserResolutionResult findOrCreateUser(JsScriptRequest request) {
        return userRepository.findByPhoneNumber(request.getPhoneNumber())
                .map(user -> new UserResolutionResult(user, false))
                .orElseGet(() -> createUser(request));
    }

    public UserAccount findExistingUser(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for phoneNumber=" + phoneNumber));
    }

    private UserResolutionResult createUser(JsScriptRequest request) {
        LocalDateTime now = LocalDateTime.now();

        UserAccount userAccount = new UserAccount();
        userAccount.setPhoneNumber(request.getPhoneNumber());
        userAccount.setMacAddress(request.getMacAddress());
        userAccount.setUserName(request.getUserName());
        userAccount.setBalanceAmount(STARTING_BALANCE);
        userAccount.setLastModifiedDate(now);

        boolean inserted = userRepository.insert(userAccount);
        if (!inserted) {
            log.info("User already existed for phoneNumber={}", request.getPhoneNumber());
            return userRepository.findByPhoneNumber(request.getPhoneNumber())
                    .map(existing -> new UserResolutionResult(existing, false))
                    .orElse(new UserResolutionResult(userAccount, true));
        }

        log.info("Created new user for phoneNumber={}", request.getPhoneNumber());
        return new UserResolutionResult(userAccount, true);
    }
}
