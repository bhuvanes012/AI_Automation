package ai.util;

import ai.entity.PricingDetail;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class BillingCalculator {

    private static final BigDecimal MILLION = BigDecimal.valueOf(1_000_000L);

    private BillingCalculator() {
    }

    public static BigDecimal calculateTotalCost(long inputTokens,
                                                long outputTokens,
                                                long cacheTokens,
                                                PricingDetail pricingDetail) {
        BigDecimal inputCost = calculateComponent(inputTokens, pricingDetail.getInputTokenPricePerMillion());
        BigDecimal outputCost = calculateComponent(outputTokens, pricingDetail.getOutputTokenPricePerMillion());
        BigDecimal cacheCost = calculateComponent(cacheTokens, pricingDetail.getCacheTokenPricePerMillion());
        return inputCost.add(outputCost).add(cacheCost).setScale(6, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateComponent(long tokens, BigDecimal pricePerMillion) {
        return BigDecimal.valueOf(tokens)
                .divide(MILLION, 12, RoundingMode.HALF_UP)
                .multiply(pricePerMillion)
                .setScale(6, RoundingMode.HALF_UP);
    }
}
