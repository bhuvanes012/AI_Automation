CREATE TABLE IF NOT EXISTS users (
    phone_number TEXT PRIMARY KEY UNIQUE NOT NULL,
    mac_address TEXT,
    user_name TEXT,
    balance_amount REAL NOT NULL,
    last_modified_date TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS interaction_details (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone_number TEXT NOT NULL,
    interaction_time TIMESTAMP NOT NULL,
    input_tokens INTEGER NOT NULL,
    output_tokens INTEGER NOT NULL,
    cache_tokens INTEGER NOT NULL,
    current_balance REAL NOT NULL,
    FOREIGN KEY (phone_number) REFERENCES users(phone_number)
);

CREATE TABLE IF NOT EXISTS pricing_details (
    id INTEGER PRIMARY KEY,
    input_token_price_per_million REAL NOT NULL,
    output_token_price_per_million REAL NOT NULL,
    cache_token_price_per_million REAL NOT NULL
);
