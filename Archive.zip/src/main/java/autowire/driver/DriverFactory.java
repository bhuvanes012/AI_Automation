package autowire.driver;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public final class DriverFactory {

    private DriverFactory() {
    }

    private static final ThreadLocal<WebDriver> threadLocalDriver = new ThreadLocal<>();

    public static void createDriver( ) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.automationtesting.in/Register.html");
        threadLocalDriver.set(driver);
    }

    public static WebDriver getDriver() {
        if(threadLocalDriver.get()==null){
            createDriver();
        }
        return threadLocalDriver.get();
    }

    public static void quitDriver() {

        WebDriver driver = threadLocalDriver.get();

        if (driver != null) {
            driver.quit();
            threadLocalDriver.remove();
        }
    }
}
