package autowire.utility;

public class AppStart {
    public static void main(String[] args) {
        try {
            CodeGen.startCodeGen();
        } catch (Throwable t) {
            System.err.println("Application failed to start: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
}
