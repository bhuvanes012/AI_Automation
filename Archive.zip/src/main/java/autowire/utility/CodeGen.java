package autowire.utility;

import ai.core.App;
import ai.model.FrameworkConfig;

import java.io.InputStream;
import java.util.Properties;

public class CodeGen {
    private static final Properties properties = new Properties();

    static {
        try (InputStream is =
                     CodeGen.class.getClassLoader().getResourceAsStream("config/framework.properties")) {

            if (is == null) {
                throw new IllegalStateException("framework.properties not found");
            }

            properties.load(is);

        } catch (Exception e) {
            throw new IllegalStateException("Unable to load framework.properties", e);
        }
    }

    public static String get(String key) {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(key + " not found in framework.properties");
        }
        return value;
    }
    public static void  startCodeGen(){
        try {
            String pomPath = get("pom.folder");
            String stepDefinitionPath = get("stepdefinition.folder");
            String featurePath = get("feature.folder");
            String applicationUrl = get("applicationUrl");


            FrameworkConfig frameworkConfig = new FrameworkConfig(pomPath, stepDefinitionPath, featurePath,applicationUrl);
            frameworkConfig.setApplicationUrl(applicationUrl);
            App.startCodeGen(frameworkConfig);
        } catch (Exception e) {
            System.err.println("Code generation failed: " + e.getMessage());
        }
    }
}
