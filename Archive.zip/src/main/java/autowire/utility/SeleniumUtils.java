package autowire.utility;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class SeleniumUtils {


    public static void highlightElement(WebDriver driver, WebElement element) {

        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;

            String originalStyle = element.getAttribute("style");

            js.executeScript(
                    "arguments[0].setAttribute('style', "
                            + "'border: 3px solid red; background: yellow;');",
                    element
            );

            Thread.sleep(1000);

            js.executeScript(
                    "arguments[0].setAttribute('style', arguments[1]);",
                    element,
                    originalStyle
            );

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Unable to highlight element: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unable to highlight element: " + e.getMessage());
        }
    }

    public static void click(WebDriver driver, By locator) {
        driver.findElement(locator).click();
    }

    public static void type(WebDriver driver, By locator, String text) {
        WebElement element = driver.findElement(locator);
        element.clear();
        element.sendKeys(text);
    }

    public static String getText(WebDriver driver, By locator) {
        return driver.findElement(locator).getText();
    }

    public static void selectByVisibleText(
            WebElement dropdown,
            String visibleText) {

        Select select = new Select(dropdown);
        select.selectByVisibleText(visibleText);
    }

    public static void hoverOverElement(
            WebDriver driver,
            By locator) {

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(locator))
                .perform();
    }

    public static void scrollintoView(
            WebDriver driver,
            WebElement element) {

        JavascriptExecutor js =
                (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].scrollIntoView(true);",
                element);
    }

    public static void clickViaJS(
            WebDriver driver,
            WebElement element) {

        JavascriptExecutor js =
                (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].click();",
                element);
    }

    public static Alert waitForAlert(
            WebDriver driver,
            long timeoutSec) {

        WebDriverWait wait =
                new WebDriverWait(
                        driver,
                        Duration.ofSeconds(timeoutSec));

        return wait.until(
                ExpectedConditions.alertIsPresent());
    }

    public static void acceptAlert(
            WebDriver driver) {

        driver.switchTo().alert().accept();
    }

    public static void dismissAlert(
            WebDriver driver) {

        driver.switchTo().alert().dismiss();
    }

    public static String getAlertText(
            WebDriver driver) {

        return driver.switchTo()
                .alert()
                .getText();
    }

    public static List<String> getAllOptionsText(
            WebElement dropdown) {

        Select select = new Select(dropdown);

        List<String> optionsText =
                new ArrayList<>();

        for (WebElement option : select.getOptions()) {
            optionsText.add(option.getText());
        }

        return optionsText;
    }

    public static boolean isTextPresent(
            WebDriver driver,
            String text) {

        return driver.getPageSource()
                .contains(text);
    }

    public static boolean isElementDisplayed(
            WebDriver driver,
            By locator) {

        try {
            return driver.findElement(locator)
                    .isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isAlertPresent(
            WebDriver driver) {

        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }
}
