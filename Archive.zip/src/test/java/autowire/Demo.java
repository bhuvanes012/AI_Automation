package autowire;

//import ai.core.App;

import autowire.utility.CodeGen;

public class Demo {

    public static void main(String[] args) {
        try {
            CodeGen.startCodeGen();
        } catch (Throwable t) {
            System.err.println("Demo failed to start: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
}
