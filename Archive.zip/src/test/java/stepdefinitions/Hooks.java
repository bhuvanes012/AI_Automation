package stepdefinitions;

import autowire.driver.DriverFactory;
import autowire.utility.CodeGen;
import autowire.utility.Helper;
import autowire.utility.Reporter;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;
import io.qameta.allure.Allure;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * Cucumber lifecycle hooks shared by all step definitions.
 */
public class Hooks {
    private static final Properties properties = new Properties();



    @BeforeAll
    public static  void beforeAll(){
        try (InputStream is =
                     CodeGen.class.getClassLoader().getResourceAsStream("config/framework.properties")) {

            if (is == null) {
                throw new IllegalStateException("framework.properties not found");
            }

            properties.load(is);

        } catch (Exception e) {
            throw new IllegalStateException("Unable to load framework.properties", e);
        }
    }

    @Before
    public void beforeScenario(Scenario scenario) {
        Reporter.clear();
        Reporter.reportlog("Start scenario: " + scenario.getName());
        DriverFactory.createDriver();
        DriverFactory.getDriver().get(Helper.get("applicationUrl",properties));

    }

    @After
    public void afterScenario(Scenario scenario) {
        String status = scenario.isFailed() ? "FAIL" : "PASS";
        Reporter.reporter(status, "Scenario " + scenario.getName() + " finished with status " + status);

        Allure.addAttachment("Execution report", "text/plain", new Reporter().toString());

        if (scenario.isFailed()) {
            attachScreenshot();
        }

        DriverFactory.quitDriver();
    }

    private void attachScreenshot() {
        if (DriverFactory.getDriver() instanceof TakesScreenshot screenshotDriver) {
            byte[] screenshot = screenshotDriver.getScreenshotAs(OutputType.BYTES);
            Allure.addAttachment(
                    "Failure screenshot",
                    "image/png",
                    new ByteArrayInputStream(screenshot),
                    "png"
            );
        }
    }
}
